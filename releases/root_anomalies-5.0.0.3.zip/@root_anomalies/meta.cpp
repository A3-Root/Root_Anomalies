protocol = 1;
publishedid = 0;
name = "Root's Anomalies";
timestamp = 639164346750000000;
