protocol = 1;
publishedid = 0;
name = "Root's Anomalies";
timestamp = 639270791020000000;
