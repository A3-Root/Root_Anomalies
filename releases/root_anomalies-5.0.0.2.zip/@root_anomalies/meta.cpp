protocol = 1;
publishedid = 0;
name = "Root's Anomalies";
timestamp = 639159114060000000;
